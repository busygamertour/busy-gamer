import React, { useEffect, useState } from 'react';
import { ArrowUpRight, CheckCircle2, ExternalLink, ShieldCheck } from 'lucide-react';
import {
  DAILY_SCHEDULE_SLOTS,
  SEO_SEARCH_KEYWORDS,
  TOURNAMENT_DIVISIONS,
  TOURNAMENT_FAQS,
  TOURNAMENT_IMAGES,
} from './data/tournamentData';
import {
  OFFICIAL_CONFIG,
  SecurityVerificationResult,
  executeVerifiedRedirect,
  getVerifiedDestinationUrl,
  startDomLinkGuardian,
} from './security/redirectGuard';
import { SeoAndHostingModal } from './components/SeoAndHostingModal';

export default function App() {
  const [lang, setLang] = useState<'bn' | 'en'>('bn');
  const [adTouchEnabled, setAdTouchEnabled] = useState<boolean>(true);
  const [scheduleFilter, setScheduleFilter] = useState<'all' | 'br' | 'cs' | 'free'>('all');
  const [isSeoModalOpen, setIsSeoModalOpen] = useState<boolean>(false);
  const [redirectBanner, setRedirectBanner] = useState<{
    active: boolean;
    sourceZone: string;
    checksumHex: string;
  } | null>(null);

  // Quick-Entry Pre-Registration Form State
  const [playerUid, setPlayerUid] = useState<string>('');
  const [selectedDivision, setSelectedDivision] = useState<string>(TOURNAMENT_DIVISIONS[0].id);
  const [formError, setFormError] = useState<string>('');

  // Image Fallback States (Zero-Broken-Image Policy)
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});

  // Security Guardian State
  const [securityStatus, setSecurityStatus] = useState<SecurityVerificationResult>(() =>
    getVerifiedDestinationUrl(OFFICIAL_CONFIG.targetUrl)
  );

  useEffect(() => {
    const stopGuardian = startDomLinkGuardian(() => {
      setSecurityStatus(getVerifiedDestinationUrl(OFFICIAL_CONFIG.targetUrl));
    });
    return () => stopGuardian();
  }, []);

  const triggerTournamentRedirect = (sourceZone: string) => {
    const verified = executeVerifiedRedirect(sourceZone);
    setSecurityStatus(verified);
    setRedirectBanner({
      active: true,
      sourceZone,
      checksumHex: verified.checksumHex,
    });
  };

  const handleGlobalAdSurfaceClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!adTouchEnabled || isSeoModalOpen) return;

    // Do not double-trigger if user clicked inside an explicit interactive control that handles its own action
    const target = e.target as HTMLElement;
    if (target.closest('[data-no-ad-redirect="true"]')) {
      return;
    }

    triggerTournamentRedirect('full_page_ad_touch');
  };

  const handleQuickJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const trimmed = playerUid.trim();
    if (trimmed.length < 5) {
      setFormError(
        lang === 'bn'
          ? 'অনুগ্রহ করে আপনার সঠিক ইন-গেম UID বা প্লেয়ার নাম লিখুন (কমপক্ষে ৫ অক্ষর)।'
          : 'Please enter a valid In-Game UID or Player Tag (minimum 5 characters).'
      );
      return;
    }
    setFormError('');
    triggerTournamentRedirect(`quick_uid_${selectedDivision}`);
  };

  const filteredSchedule = DAILY_SCHEDULE_SLOTS.filter((slot) => {
    if (scheduleFilter === 'all') return true;
    if (scheduleFilter === 'br') return slot.division.includes('Battle Royale') || slot.division.includes('Squad');
    if (scheduleFilter === 'cs') return slot.division.includes('Clash Squad') || slot.division.includes('Lone Wolf');
    if (scheduleFilter === 'free') return slot.entryFee.includes('Free') || slot.entryFee === '৳0';
    return true;
  });

  return (
    <div
      onClick={handleGlobalAdSurfaceClick}
      className={`min-h-screen bg-[#0A0A0B] text-[#F5F5F0] selection:bg-amber-500 selection:text-neutral-950 ${
        adTouchEnabled ? 'cursor-pointer' : 'cursor-default'
      }`}
    >
      {/* Top Navigation Bar — Strictly 3 Zones per Top Bar Contract */}
      <header
        data-no-ad-redirect="true"
        className="sticky top-0 z-40 flex items-center justify-between border-b border-neutral-800/80 bg-[#0A0A0B]/90 backdrop-blur-md px-6 py-4"
      >
        {/* Zone 1: Single text element Brand Wordmark */}
        <a
          href={OFFICIAL_CONFIG.targetUrl}
          target="_blank"
          rel="noopener noreferrer"
          data-protected-link="true"
          onClick={() => triggerTournamentRedirect('header_brand')}
          className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap"
        >
          Busy Gamer Tournament
        </a>

        {/* Zone 2: 5 Clean Typography Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-neutral-400">
          <a
            href="#divisions"
            onClick={(e) => {
              if (adTouchEnabled) {
                e.preventDefault();
                triggerTournamentRedirect('nav_divisions');
              }
            }}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            {lang === 'bn' ? 'টুর্নামেন্ট সমূহ' : 'Divisions'}
          </a>
          <a
            href="#schedule"
            onClick={(e) => {
              if (adTouchEnabled) {
                e.preventDefault();
                triggerTournamentRedirect('nav_schedule');
              }
            }}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            {lang === 'bn' ? 'ম্যাচ শিডিউল' : 'Live Schedule'}
          </a>
          <a
            href="#proof"
            onClick={(e) => {
              if (adTouchEnabled) {
                e.preventDefault();
                triggerTournamentRedirect('nav_proof');
              }
            }}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            {lang === 'bn' ? 'ফেয়ার প্লে ও পেমেন্ট' : 'Fair Play & Payouts'}
          </a>
          <a
            href="#faq"
            onClick={(e) => {
              if (adTouchEnabled) {
                e.preventDefault();
                triggerTournamentRedirect('nav_faq');
              }
            }}
            className="hover:text-white hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            {lang === 'bn' ? 'সচরাচর জিজ্ঞাসা' : 'FAQ'}
          </a>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsSeoModalOpen(true);
            }}
            className="text-neutral-300 hover:text-amber-400 hover:underline underline-offset-4 transition-colors whitespace-nowrap"
          >
            SEO & Security Kit
          </button>
        </nav>

        {/* Zone 3: 2 Primary Actions (Language Switcher + Official Launch CTA) */}
        <div className="flex items-center gap-3">
          <div className="flex items-center rounded-lg border border-neutral-800 bg-[#121316] p-0.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setLang('bn');
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                lang === 'bn' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              বাংলা
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setLang('en');
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                lang === 'en' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              EN
            </button>
          </div>

          <a
            href={OFFICIAL_CONFIG.targetUrl}
            target="_blank"
            rel="noopener noreferrer"
            data-protected-link="true"
            onClick={() => triggerTournamentRedirect('header_cta')}
            className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-4 py-2 text-xs font-semibold text-neutral-950 hover:bg-amber-400 transition-colors whitespace-nowrap shrink-0"
          >
            <span>{lang === 'bn' ? 'অ্যাপে প্রবেশ করুন' : 'Enter Official App'}</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </div>
      </header>

      {/* Instant Redirect Handshake Notification Drawer (For Sandboxed Previews & Instant Verification) */}
      {redirectBanner?.active && (
        <div
          data-no-ad-redirect="true"
          className="border-b border-amber-500/30 bg-[#16130B] px-6 py-3 text-xs text-neutral-200"
        >
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-amber-400 shrink-0" />
              <span>
                {lang === 'bn'
                  ? 'ভেরিফাইড রিডাইরেক্ট সক্রিয় হয়েছে — আপনাকে অফিসিয়াল Busy Gamer Tournament পোর্টালে নিয়ে যাওয়া হচ্ছে।'
                  : 'Verified redirect triggered — opening the official Busy Gamer Tournament portal.'}
              </span>
              <span className="hidden sm:inline text-neutral-500">·</span>
              <span className="hidden sm:inline font-mono-tabular text-neutral-400">
                Integrity {redirectBanner.checksumHex}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <a
                href={OFFICIAL_CONFIG.targetUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-protected-link="true"
                className="inline-flex items-center gap-1 font-semibold text-amber-400 hover:underline whitespace-nowrap"
              >
                <span>https://busy-gamer-turnament.web.app/</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setRedirectBanner(null);
                }}
                className="text-neutral-400 hover:text-white"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Promotional Ad & SEO Landing Content */}
      <main>
        {/* 1. HERO SECTION — Proposition */}
        <section className="relative overflow-hidden border-b border-neutral-800/80">
          <div className="mx-auto max-w-6xl px-6 py-14 lg:py-20">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
              {/* Left Column: High-Impact Proposition & Primary Action */}
              <div className="lg:col-span-7 space-y-6">
                {/* Clean Unboxed Metadata Line (Zero-Pill Discipline) */}
                <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 tracking-wide">
                  <span className="text-amber-400 font-medium">
                    {lang === 'bn' ? 'বাংলাদেশের অফিসিয়াল মোবাইল ইস্পোর্টস প্ল্যাটফর্ম' : 'Bangladesh Official Mobile Esports Arena'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>Free Fire & PUBG Custom Rooms</span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {lang === 'bn' ? 'যেকোনো জায়গায় টাচ করলেই অ্যাপ ওপেন হবে' : 'Tap Anywhere to Enter Official App'}
                  </span>
                </div>

                <h1 className="font-display text-3xl sm:text-5xl lg:text-[52px] font-bold tracking-tight text-white leading-[1.1]">
                  {lang === 'bn'
                    ? 'প্রতিদিন কাস্টম রুম টুর্নামেন্ট খেলুন এবং ১৫ মিনিটে বিকাশ ও নগদে পুরস্কার জিতুন'
                    : 'Compete in Daily Custom Room Tournaments with Instant bKash & Nagad Payouts'}
                </h1>

                <p className="text-base sm:text-lg text-neutral-300 leading-relaxed max-w-2xl">
                  {lang === 'bn'
                    ? 'Busy Gamer Tournament-এ প্রতিদিন চলছে ফ্রি ফায়ার, পাবজি মোবাইল, লোন উলফ ১ বনাম ১ এবং ৪ বনাম ৪ ক্ল্যাশ স্কোয়াড টুর্নামেন্ট। হ্যাকার-মুক্ত রেফারি রুম, প্রতি কিলে নিশ্চিত বোনাস এবং ফ্রি এন্ট্রি স্পন্সরড ম্যাচে জয়েন করতে পেজের যেকোনো স্থানে টাচ করুন।'
                    : 'Join Busy Gamer Tournament for referee-monitored Battle Royale, 4v4 Clash Squad, and 1v1 Lone Wolf custom rooms. Verified anti-cheat protection, guaranteed per-kill cash rewards, and zero-entry daily scrims.'}
                </p>

                {/* Single Primary CTA Block + Direct Official Link */}
                <div className="pt-2 flex flex-wrap items-center gap-4">
                  <a
                    href={OFFICIAL_CONFIG.targetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-protected-link="true"
                    onClick={() => triggerTournamentRedirect('hero_primary_cta')}
                    className="inline-flex items-center gap-2.5 rounded-lg bg-amber-500 px-6 py-3.5 text-sm font-semibold text-neutral-950 hover:bg-amber-400 transition-transform active:scale-[0.99] whitespace-nowrap"
                  >
                    <span>
                      {lang === 'bn'
                        ? 'এখনই টুর্নামেন্টে জয়েন করুন (Official App)'
                        : 'Join Today’s Tournament Room'}
                    </span>
                    <ArrowUpRight className="h-4 w-4" />
                  </a>

                  <div className="text-xs text-neutral-400 space-y-0.5">
                    <div className="text-neutral-200 font-medium">
                      {lang === 'bn' ? 'অফিসিয়াল লিংক:' : 'Official Destination:'}{' '}
                      <span className="font-mono-tabular text-amber-400">busy-gamer-turnament.web.app</span>
                    </div>
                    <div>
                      {lang === 'bn'
                        ? '১০০% ভেরিফাইড ও হ্যাকার-প্রুফ সিকিউর গেটওয়ে'
                        : 'Cryptographically locked destination · Instant Room ID delivery'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: 16:9 Championship Visual Carrier */}
              <div className="lg:col-span-5">
                <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-neutral-800 bg-[#121316]">
                  {!imgErrors.hero ? (
                    <img
                      src={TOURNAMENT_IMAGES.heroArena}
                      alt="Busy Gamer Tournament Esports Championship Stage and Custom Room Arena"
                      referrerPolicy="no-referrer"
                      onError={() => setImgErrors((prev) => ({ ...prev, hero: true }))}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-neutral-900 via-neutral-950 to-amber-950/30 p-6 text-center">
                      <span className="font-display text-lg font-bold text-white">
                        Busy Gamer Championship Arena
                      </span>
                      <span className="text-xs text-neutral-400 mt-1">
                        busy-gamer-turnament.web.app
                      </span>
                    </div>
                  )}
                  {/* Measured Contrast Scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent flex flex-col justify-end p-5">
                    <div className="text-xs text-neutral-300">
                      <span>{lang === 'bn' ? 'আজকের প্রাইম টাইম ফাইনাল' : 'Tonight’s Prime-Time Grand Room'}</span>
                      <span className="mx-1.5">·</span>
                      <span className="font-mono-tabular text-amber-400">09:30 PM BD Time</span>
                    </div>
                    <p className="font-display text-base font-bold text-white mt-0.5">
                      {lang === 'bn'
                        ? 'ব্যাটল রয়্যাল চ্যাম্পিয়নশিপ — প্রাইজপুল ৳১,২০০ + প্রতি কিল ৳১৫'
                        : 'Battle Royale Squad Championship — ৳1,200 Pool + ৳15/Kill'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 2. CORE TOURNAMENT DIVISIONS — Asymmetric Bento Grid (Mechanism / Capabilities) */}
        <section id="divisions" className="border-b border-neutral-800/80 py-16 lg:py-20">
          <div className="mx-auto max-w-6xl px-6 space-y-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="space-y-2">
                <div className="text-xs text-neutral-400">
                  <span>{lang === 'bn' ? 'গেমিং ক্যাটাগরি ও কাস্টম রুম ফরম্যাট' : 'Competitive Divisions & Formats'}</span>
                  <span className="mx-2">·</span>
                  <span>{lang === 'bn' ? 'যেকোনো কার্ডে টাচ করে রেজিস্ট্রেশন করুন' : 'Select any division to open official portal'}</span>
                </div>
                <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
                  {lang === 'bn'
                    ? 'আপনার পছন্দের গেম মোড বেছে নিন এবং টুর্নামেন্টে জয়েন করুন'
                    : 'Choose Your Tournament Format & Claim Your Custom Room Slot'}
                </h2>
              </div>
              <a
                href={OFFICIAL_CONFIG.targetUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-protected-link="true"
                className="text-xs font-semibold text-amber-400 hover:underline inline-flex items-center gap-1 whitespace-nowrap"
              >
                <span>{lang === 'bn' ? 'সবগুলো টুর্নামেন্ট রুম দেখুন' : 'View All Active Rooms on Official App'}</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>

            {/* Asymmetric Bento Grid: 2 Featured Cards with 4:3 Visuals + 2 Secondary Editorial Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {TOURNAMENT_DIVISIONS.map((div, idx) => {
                const isWide = idx === 0 || idx === 3;
                const colSpanClass = isWide ? 'lg:col-span-7' : 'lg:col-span-5';

                return (
                  <article
                    key={div.id}
                    className={`${colSpanClass} group rounded-xl border border-neutral-800 bg-[#121316] p-6 hover:border-neutral-700 transition-colors flex flex-col justify-between gap-6`}
                  >
                    <div className="space-y-4">
                      {/* Clean Unboxed Metadata Kicker */}
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-400">
                        <div>
                          <span>{div.format}</span>
                          <span className="mx-1.5">·</span>
                          <span>{div.mapPool}</span>
                        </div>
                        <span className="font-mono-tabular text-neutral-300">{div.dailySlots}</span>
                      </div>

                      {/* Natural Human Editorial Numbering */}
                      <h3 className="font-display text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                        {div.index}. {lang === 'bn' ? div.titleBn : div.titleEn}
                      </h3>

                      <p className="text-sm text-neutral-300 leading-relaxed">
                        {lang === 'bn' ? div.descriptionBn : div.descriptionEn}
                      </p>

                      {div.image && (
                        <div className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border border-neutral-800/90 bg-neutral-950 mt-2">
                          {!imgErrors[div.id] ? (
                            <img
                              src={div.image}
                              alt={div.titleEn}
                              referrerPolicy="no-referrer"
                              onError={() => setImgErrors((prev) => ({ ...prev, [div.id]: true }))}
                              className="h-full w-full object-cover group-hover:scale-[1.02] transition-transform duration-200"
                            />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center bg-neutral-900 p-4 text-xs text-neutral-400">
                              {div.titleEn}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Bottom Tabular Prize & Entry Bar */}
                    <div className="flex flex-wrap items-center justify-between gap-4 border-t border-neutral-800/90 pt-4 text-xs">
                      <div className="flex flex-wrap items-center gap-3 text-neutral-300 font-mono-tabular">
                        <span>
                          {lang === 'bn' ? 'এন্ট্রি ফি:' : 'Entry:'}{' '}
                          <strong className="text-white">
                            {div.entryFeeBdt === 0 ? (lang === 'bn' ? 'ফ্রি (৳০)' : 'Free (৳0)') : `৳${div.entryFeeBdt}`}
                          </strong>
                        </span>
                        <span aria-hidden="true">·</span>
                        {div.perKillBdt > 0 && (
                          <>
                            <span>
                              {lang === 'bn' ? 'প্রতি কিল:' : 'Per Kill:'}{' '}
                              <strong className="text-white">৳{div.perKillBdt}</strong>
                            </span>
                            <span aria-hidden="true">·</span>
                          </>
                        )}
                        <span>
                          {lang === 'bn' ? 'মোট প্রাইজ:' : 'Prize Pool:'}{' '}
                          <strong className="text-amber-400">৳{div.totalPrizeBdt}</strong>
                        </span>
                      </div>

                      <span className="inline-flex items-center gap-1 font-semibold text-white group-hover:text-amber-400 transition-colors whitespace-nowrap">
                        <span>{lang === 'bn' ? 'রুমে জয়েন করুন' : 'Join Room'}</span>
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        {/* 3. LIVE DAILY SCHEDULE & QUANTIFIED PROOF OF IMPACT (Claim-to-Proof Adjacency) */}
        <section id="schedule" className="border-b border-neutral-800/80 py-16 lg:py-20">
          <div className="mx-auto max-w-6xl px-6 space-y-12">
            {/* Schedule Header + Interactive Filter Controls */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div className="space-y-2">
                <div className="text-xs text-neutral-400">
                  <span>{lang === 'bn' ? 'প্রতিদিনের লাইভ কাস্টম রুম তালিকা' : 'Daily Automated Custom Room Schedule'}</span>
                  <span className="mx-2">·</span>
                  <span>{lang === 'bn' ? 'ম্যাচ শুরুর ১০ মিনিট আগে রুম আইডি ও পাসওয়ার্ড' : 'Room ID & Password released 10m prior'}</span>
                </div>
                <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
                  {lang === 'bn'
                    ? 'আজকের লাইভ টুর্নামেন্ট শিডিউল ও প্রাইজপুল তালিকা'
                    : 'Today’s Live Custom Room Schedule & Prize Breakdown'}
                </h2>
              </div>

              {/* Functional Segmented Filter Bar */}
              <div
                data-no-ad-redirect="true"
                className="flex items-center gap-1 rounded-lg border border-neutral-800 bg-[#121316] p-1 self-start"
              >
                <button
                  type="button"
                  onClick={() => setScheduleFilter('all')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    scheduleFilter === 'all'
                      ? 'bg-neutral-800 text-white'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {lang === 'bn' ? 'সব ম্যাচ' : 'All Matches'}
                </button>
                <button
                  type="button"
                  onClick={() => setScheduleFilter('br')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    scheduleFilter === 'br'
                      ? 'bg-neutral-800 text-white'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Battle Royale
                </button>
                <button
                  type="button"
                  onClick={() => setScheduleFilter('cs')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    scheduleFilter === 'cs'
                      ? 'bg-neutral-800 text-white'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  4v4 & 1v1
                </button>
                <button
                  type="button"
                  onClick={() => setScheduleFilter('free')}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    scheduleFilter === 'free'
                      ? 'bg-neutral-800 text-white'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {lang === 'bn' ? 'ফ্রি এন্ট্রি' : 'Free Entry'}
                </button>
              </div>
            </div>

            {/* Tabular Schedule Table */}
            <div className="overflow-x-auto rounded-xl border border-neutral-800 bg-[#121316]">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-neutral-800 text-xs text-neutral-400">
                    <th className="py-3.5 px-5 font-medium">Match ID</th>
                    <th className="py-3.5 px-5 font-medium">{lang === 'bn' ? 'সময় (BD)' : 'Start Time'}</th>
                    <th className="py-3.5 px-5 font-medium">{lang === 'bn' ? 'টুর্নামেন্ট বিভাগ' : 'Division & Rules'}</th>
                    <th className="py-3.5 px-5 font-medium">{lang === 'bn' ? 'এন্ট্রি ফি' : 'Entry Fee'}</th>
                    <th className="py-3.5 px-5 font-medium">{lang === 'bn' ? 'মোট পুরস্কার' : 'Prize Pool'}</th>
                    <th className="py-3.5 px-5 font-medium">{lang === 'bn' ? 'সিট সংখ্যা' : 'Capacity'}</th>
                    <th className="py-3.5 px-5 font-medium text-right">{lang === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/70 text-sm">
                  {filteredSchedule.map((slot) => (
                    <tr
                      key={slot.matchCode}
                      className="hover:bg-neutral-800/40 transition-colors"
                    >
                      <td className="py-4 px-5 font-mono-tabular text-xs text-neutral-300 whitespace-nowrap">
                        {slot.matchCode}
                      </td>
                      <td className="py-4 px-5 font-mono-tabular font-semibold text-white whitespace-nowrap">
                        {slot.timeBd}
                      </td>
                      <td className="py-4 px-5">
                        <div className="font-medium text-white">{slot.division}</div>
                        <div className="text-xs text-neutral-400">{slot.mode}</div>
                      </td>
                      <td className="py-4 px-5 font-mono-tabular text-neutral-200 whitespace-nowrap">
                        {slot.entryFee}
                      </td>
                      <td className="py-4 px-5 font-mono-tabular font-semibold text-amber-400 whitespace-nowrap">
                        {slot.prizePool}
                      </td>
                      <td className="py-4 px-5 font-mono-tabular text-xs text-neutral-300 whitespace-nowrap">
                        {slot.spotsFilled} · <span className="text-neutral-400">{slot.statusLabel}</span>
                      </td>
                      <td className="py-4 px-5 text-right whitespace-nowrap">
                        <a
                          href={OFFICIAL_CONFIG.targetUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          data-protected-link="true"
                          className="inline-flex items-center gap-1 text-xs font-semibold text-amber-400 hover:text-amber-300"
                        >
                          <span>{lang === 'bn' ? 'বুক করুন' : 'Book Slot'}</span>
                          <ArrowUpRight className="h-3.5 w-3.5" />
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Proof of Impact & Verified Player Testimonials (Immediately Adjacent to Schedule) */}
            <div id="proof" className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-4">
              {/* Quantified Track Record */}
              <div className="lg:col-span-5 rounded-xl border border-neutral-800 bg-[#121316] p-6 flex flex-col justify-between space-y-6">
                <div className="space-y-2">
                  <div className="text-xs text-neutral-400">
                    {lang === 'bn' ? 'ভেরিফাইড ট্র্যাক রেকর্ড (২০২৫–২০২৬)' : 'Verified Platform Record (Last 12 Months)'}
                  </div>
                  <h3 className="font-display text-xl font-bold text-white">
                    {lang === 'bn'
                      ? 'কেন হাজার হাজার গেমার প্রতিদিন Busy Gamer Tournament-এ খেলে?'
                      : 'Quantified Payout Speed & Anti-Cheat Enforcement'}
                  </h3>
                </div>

                <div className="space-y-4 border-t border-neutral-800 pt-4">
                  <div>
                    <div className="font-mono-tabular text-2xl font-bold text-white">
                      18,400+ Custom Rooms Hosted
                    </div>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      {lang === 'bn'
                        ? 'গত ১২ মাসে ৯৯.৪% অন-টাইম রুম আইডি ডেলিভারি এবং লাইভ রেফারি মনিটরিং।'
                        : '99.4% on-time Room ID dispatch over the past 12 months across BD servers.'}
                    </p>
                  </div>

                  <div className="border-t border-neutral-800/80 pt-4">
                    <div className="font-mono-tabular text-2xl font-bold text-amber-400">
                      11.5 Mins Median Payout Time
                    </div>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      {lang === 'bn'
                        ? 'ম্যাচ শেষ হওয়ার পর গড়ে ১১.৫ মিনিটের মধ্যে বিকাশ, নগদ ও রকেটে সরাসরি ক্যাশআউট।'
                        : 'Automated scoreboard verification to bKash/Nagad wallet settlement in under 15 minutes.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Attributable Player Testimonials */}
              <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
                <blockquote className="rounded-xl border border-neutral-800 bg-[#121316] p-6 flex flex-col justify-between space-y-4">
                  <p className="text-sm text-neutral-300 leading-relaxed">
                    {lang === 'bn'
                      ? '“আগে অন্য টুর্নামেন্ট গ্রুপে খেললে এমুলেটর প্লেয়ার আর পেমেন্ট আটকে থাকার সমস্যা হতো। Busy Gamer Tournament-এ গত ৩ মাসে আমাদের স্কোয়াড ৪২টি ক্ল্যাশ স্কোয়াড ম্যাচ খেলেছে এবং প্রতিবারই ১৫ মিনিটের মধ্যে বিকাশে প্রাইজমানি পেয়েছি।”'
                      : '“Before switching to Busy Gamer Tournament, our squad constantly faced PC emulators and delayed payouts in random rooms. Over the last 3 months we played 42 Clash Squad matches here and received every bKash payout within 15 minutes.”'}
                  </p>
                  <footer className="border-t border-neutral-800 pt-3 text-xs">
                    <div className="font-semibold text-white">Tanvir Hasan (IGN: TH_ViperBD)</div>
                    <div className="text-neutral-400">
                      Squad IGL, Crimson Vipers BD · Dhaka Division
                    </div>
                  </footer>
                </blockquote>

                <blockquote className="rounded-xl border border-neutral-800 bg-[#121316] p-6 flex flex-col justify-between space-y-4">
                  <p className="text-sm text-neutral-300 leading-relaxed">
                    {lang === 'bn'
                      ? '“রাত ৮টার ফ্রি এন্ট্রি স্ক্রিম দিয়ে শুরু করেছিলাম। সেখান থেকে ওয়ালেট ব্যালেন্স জমিয়ে এখন প্রতিদিন পেইড ফুল-ম্যাপ টুর্নামেন্ট খেলি। অ্যাপে রুম আইডি ঠিক ১০ মিনিট আগেই চলে আসে, কোনো ঝামেলা হয় না।”'
                      : '“I started with the 8:00 PM free-entry scrims, built my wallet balance from per-kill rewards, and now compete daily in solo Battle Royale rooms. Room ID and password appear right inside the app 10 minutes before start.”'}
                  </p>
                  <footer className="border-t border-neutral-800 pt-3 text-xs">
                    <div className="font-semibold text-white">Mehedi Riyad (IGN: RiyadX99)</div>
                    <div className="text-neutral-400">
                      Solo Battle Royale Finalist · Chattogram
                    </div>
                  </footer>
                </blockquote>
              </div>
            </div>
          </div>
        </section>

        {/* 4. BILINGUAL GOOGLE SEO FAQ & INSTANT UID ENTRY PORTAL (Conversion / Action) */}
        <section id="faq" className="py-16 lg:py-20">
          <div className="mx-auto max-w-6xl px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              {/* Left 7 Columns: Search-Indexed Bilingual FAQ */}
              <div className="lg:col-span-7 space-y-6">
                <div className="space-y-2">
                  <div className="text-xs text-neutral-400">
                    {lang === 'bn'
                      ? 'গুগল ও ক্রোম সার্চ ইনডেক্সড প্রশ্নোত্তর (Schema.org FAQ)'
                      : 'Frequently Asked Questions & Rules'}
                  </div>
                  <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
                    {lang === 'bn'
                      ? 'টুর্নামেন্টে অংশগ্রহণ ও পুরস্কার উত্তোলনের নিয়মাবলী'
                      : 'How Busy Gamer Tournament Works'}
                  </h2>
                </div>

                <dl className="divide-y divide-neutral-800 border-t border-b border-neutral-800">
                  {TOURNAMENT_FAQS.map((faq, index) => (
                    <div key={index} className="py-5 space-y-2">
                      <dt className="font-display text-base font-bold text-white">
                        {lang === 'bn' ? faq.questionBn : faq.questionEn}
                      </dt>
                      <dd className="text-sm text-neutral-300 leading-relaxed">
                        {lang === 'bn' ? faq.answerBn : faq.answerEn}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>

              {/* Right 5 Columns: Direct UID Pre-Check & Official Portal Launcher */}
              <div
                data-no-ad-redirect="true"
                className="lg:col-span-5 rounded-xl border border-neutral-800 bg-[#121316] p-6 sm:p-8 space-y-6"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>{lang === 'bn' ? 'ডিরেক্ট প্লেয়ার এন্ট্রি গেটওয়ে' : 'Direct Player Entry Gateway'}</span>
                    <span className="font-mono-tabular text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="h-3.5 w-3.5" />
                      Verified SSL
                    </span>
                  </div>
                  <h3 className="font-display text-xl font-bold text-white">
                    {lang === 'bn'
                      ? 'আপনার গেম UID দিয়ে সরাসরি টুর্নামেন্ট অ্যাপে প্রবেশ করুন'
                      : 'Enter Your In-Game UID & Open Official Tournament App'}
                  </h3>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {lang === 'bn'
                      ? 'নিচে আপনার ইন-গেম নাম বা UID লিখে বাটনে ক্লিক করুন অথবা পেজের যেকোনো জায়গায় টাচ করে সরাসরি অফিসিয়াল অ্যাপে যান।'
                      : 'Verify your player tag below or tap anywhere on the page to launch https://busy-gamer-turnament.web.app/.'}
                  </p>
                </div>

                <form onSubmit={handleQuickJoinSubmit} className="space-y-4">
                  <div>
                    <label
                      htmlFor="player-uid-input"
                      className="block text-xs font-medium text-neutral-300 mb-1.5"
                    >
                      {lang === 'bn' ? 'আপনার ইন-গেম নাম বা UID (Free Fire / PUBG / eFootball)' : 'In-Game Name or Player UID'}
                    </label>
                    <input
                      id="player-uid-input"
                      type="text"
                      value={playerUid}
                      onChange={(e) => {
                        setPlayerUid(e.target.value);
                        if (formError) setFormError('');
                      }}
                      placeholder={lang === 'bn' ? 'যেমন: 2849104821 অথবা BD_Sniper' : 'e.g. 2849104821 or BD_Sniper'}
                      className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3.5 py-2.5 text-sm text-white placeholder:text-neutral-500 focus:border-amber-500 focus:outline-none"
                    />
                    {formError && (
                      <p className="mt-1.5 text-xs text-amber-400">{formError}</p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="division-select"
                      className="block text-xs font-medium text-neutral-300 mb-1.5"
                    >
                      {lang === 'bn' ? 'পছন্দের টুর্নামেন্ট মোড' : 'Preferred Tournament Division'}
                    </label>
                    <select
                      id="division-select"
                      value={selectedDivision}
                      onChange={(e) => setSelectedDivision(e.target.value)}
                      className="w-full rounded-lg border border-neutral-700 bg-neutral-950 px-3.5 py-2.5 text-sm text-white focus:border-amber-500 focus:outline-none"
                    >
                      {TOURNAMENT_DIVISIONS.map((div) => (
                        <option key={div.id} value={div.id}>
                          {lang === 'bn' ? div.titleBn : div.titleEn}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 rounded-lg bg-amber-500 px-5 py-3 text-sm font-semibold text-neutral-950 hover:bg-amber-400 transition-colors whitespace-nowrap"
                  >
                    <span>
                      {lang === 'bn'
                        ? 'অফিসিয়াল অ্যাপে স্লট বুক করুন'
                        : 'Continue to Official Tournament App'}
                    </span>
                    <ArrowUpRight className="h-4 w-4" />
                  </button>
                </form>

                <div className="border-t border-neutral-800 pt-4 text-xs text-neutral-400 space-y-1">
                  <div>
                    {lang === 'bn' ? 'সুরক্ষিত ডেস্টিনেশন লিংক:' : 'Protected Destination URL:'}{' '}
                    <a
                      href={OFFICIAL_CONFIG.targetUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-protected-link="true"
                      className="font-mono-tabular text-neutral-200 hover:text-amber-400 underline"
                    >
                      https://busy-gamer-turnament.web.app/
                    </a>
                  </div>
                  <div>
                    {lang === 'bn'
                      ? 'অ্যাডমিন ও ডেভেলপার অপশন দেখতে উপরের "SEO & Security Kit" বাটনে ক্লিক করুন।'
                      : 'Click "SEO & Security Kit" in the top bar to copy Firebase Hosting security headers.'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 5. QUIET FOOTER — Semantic Search Index + Official Mirror */}
      <footer className="border-t border-neutral-800 bg-[#0A0A0B] py-12 text-xs text-neutral-400">
        <div className="mx-auto max-w-6xl px-6 space-y-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="font-display text-sm font-bold text-white">
                Busy Gamer Tournament — Official Mobile Esports Portal
              </div>
              <div>
                Official Web App:{' '}
                <a
                  href={OFFICIAL_CONFIG.targetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-protected-link="true"
                  className="font-mono-tabular text-neutral-300 hover:text-amber-400 underline"
                >
                  https://busy-gamer-turnament.web.app/
                </a>
              </div>
            </div>

            <div data-no-ad-redirect="true" className="flex flex-wrap items-center gap-5">
              <button
                type="button"
                onClick={() => setIsSeoModalOpen(true)}
                className="hover:text-white transition-colors"
              >
                SEO & Firebase Hosting Kit
              </button>
              <button
                type="button"
                onClick={() => setAdTouchEnabled((prev) => !prev)}
                className="hover:text-white transition-colors"
              >
                {adTouchEnabled ? 'Ad Touch Mode: Active' : 'Ad Touch Mode: Paused'}
              </button>
              <a
                href={OFFICIAL_CONFIG.targetUrl}
                target="_blank"
                rel="noopener noreferrer"
                data-protected-link="true"
                className="text-amber-400 font-semibold hover:underline"
              >
                Launch Portal
              </a>
            </div>
          </div>

          {/* Search Engine Crawlable Keyword Summary (Clean Unboxed Text) */}
          <div className="border-t border-neutral-800/70 pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-neutral-500">
            <p className="max-w-3xl leading-relaxed">
              Indexed Topics: {SEO_SEARCH_KEYWORDS.join(' · ')}
            </p>
            <p className="whitespace-nowrap">
              © {new Date().getFullYear()} Busy Gamer Tournament. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* SEO & Anti-Tamper Hosting Control Modal */}
      <SeoAndHostingModal
        isOpen={isSeoModalOpen}
        onClose={() => setIsSeoModalOpen(false)}
        securityStatus={securityStatus}
        adTouchEnabled={adTouchEnabled}
        onToggleAdTouch={setAdTouchEnabled}
      />
    </div>
  );
}
