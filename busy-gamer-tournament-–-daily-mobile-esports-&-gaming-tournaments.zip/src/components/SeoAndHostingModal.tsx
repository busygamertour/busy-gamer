import React, { useState } from 'react';
import { Check, Copy, ExternalLink, Search, ShieldCheck, X } from 'lucide-react';
import { OFFICIAL_CONFIG, SecurityVerificationResult } from '../security/redirectGuard';
import { SEO_SEARCH_KEYWORDS } from '../data/tournamentData';

interface SeoAndHostingModalProps {
  isOpen: boolean;
  onClose: () => void;
  securityStatus: SecurityVerificationResult;
  adTouchEnabled: boolean;
  onToggleAdTouch: (enabled: boolean) => void;
}

const FIREBASE_JSON_SNIPPET = `{
  "hosting": {
    "public": "dist",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [{ "source": "**", "destination": "/index.html" }],
    "headers": [
      {
        "source": "**",
        "headers": [
          { "key": "X-Content-Type-Options", "value": "nosniff" },
          { "key": "X-Frame-Options", "value": "SAMEORIGIN" },
          { "key": "Strict-Transport-Security", "value": "max-age=63072000; includeSubDomains; preload" },
          { "key": "Content-Security-Policy", "value": "default-src 'self' https://busy-gamer-turnament.web.app; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; frame-ancestors 'self';" }
        ]
      }
    ]
  }
}`;

export const SeoAndHostingModal: React.FC<SeoAndHostingModalProps> = ({
  isOpen,
  onClose,
  securityStatus,
  adTouchEnabled,
  onToggleAdTouch,
}) => {
  const [activeTab, setActiveTab] = useState<'seo' | 'security' | 'hosting'>('seo');
  const [searchPreviewQuery, setSearchPreviewQuery] = useState('ফ্রি ফায়ার টুর্নামেন্ট বাংলাদেশ / Busy Gamer Tournament');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="w-full max-w-3xl rounded-xl border border-neutral-800 bg-[#121316] text-[#F5F5F0] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-white">
              SEO Indexing & Anti-Tamper Hosting Control
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Configured for Google & Chrome Search Discovery + Protected Redirect to {OFFICIAL_CONFIG.host}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
            aria-label="Close settings modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Interactive Mode Switcher Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-neutral-800 bg-neutral-900/60 px-6 py-3">
          <div className="text-xs text-neutral-300">
            <span className="font-semibold text-white">Full-Page Touch Redirect Mode: </span>
            <span>
              {adTouchEnabled
                ? 'Active (Touching anywhere on the page sends visitor to official app)'
                : 'Paused for inspection (Only CTA buttons trigger redirect)'}
            </span>
          </div>
          <div className="flex items-center gap-1 rounded-lg bg-neutral-950 p-1 border border-neutral-800">
            <button
              type="button"
              onClick={() => onToggleAdTouch(true)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                adTouchEnabled
                  ? 'bg-amber-500 text-neutral-950 font-semibold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Tap-Anywhere Ad ON
            </button>
            <button
              type="button"
              onClick={() => onToggleAdTouch(false)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                !adTouchEnabled
                  ? 'bg-neutral-800 text-white font-semibold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Inspect Page Mode
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 border-b border-neutral-800 px-6 pt-3 bg-[#121316]">
          <button
            type="button"
            onClick={() => setActiveTab('seo')}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'seo'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Google & Chrome SEO Preview
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('security')}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'security'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Anti-Hacker Link Protection
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('hosting')}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'hosting'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            Firebase & Static Hosting Config
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 max-h-[68vh] overflow-y-auto space-y-5">
          {activeTab === 'seo' && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-medium text-neutral-400 mb-2">
                  Test how your page appears when gamers search on Google or Chrome:
                </label>
                <div className="flex items-center gap-2 rounded-lg border border-neutral-700 bg-neutral-950 px-3.5 py-2">
                  <Search className="h-4 w-4 text-neutral-400 shrink-0" />
                  <input
                    type="text"
                    value={searchPreviewQuery}
                    onChange={(e) => setSearchPreviewQuery(e.target.value)}
                    className="w-full bg-transparent text-sm text-white focus:outline-none"
                    placeholder="Type any gaming or tournament keyword..."
                  />
                </div>
              </div>

              {/* Simulated Google Mobile / Chrome SERP Snippet */}
              <div className="rounded-xl border border-neutral-800 bg-[#18191D] p-5 space-y-3">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span>Google Search Rich Result Preview (JSON-LD Enabled)</span>
                  <span className="font-mono-tabular text-emerald-400">Schema.org Validated</span>
                </div>
                <div className="border-t border-neutral-800 pt-3 space-y-1.5">
                  <div className="text-xs text-neutral-300 flex items-center gap-1.5">
                    <span className="font-semibold text-white">Busy Gamer Tournament</span>
                    <span>·</span>
                    <span className="text-neutral-400">https://busy-gamer-turnament.web.app</span>
                  </div>
                  <h3 className="text-base font-semibold text-amber-400 hover:underline cursor-pointer">
                    Busy Gamer Tournament – Daily Mobile Esports & Gaming Tournaments
                  </h3>
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    Join Busy Gamer Tournament for daily Free Fire, PUBG Mobile, and eFootball custom rooms,
                    instant bKash/Nagad prize payouts, and verified fair-play brackets. বিজি গেমার টুর্নামেন্টে প্রতিদিন কাস্টম রুম খেলে পুরস্কার জিতুন।
                  </p>
                  <div className="pt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-neutral-400">
                    <span>Event Status: Daily Live Rooms</span>
                    <span>·</span>
                    <span>Entry: Free – ৳80 BDT</span>
                    <span>·</span>
                    <span>Payout: Instant bKash / Nagad</span>
                  </div>
                </div>
              </div>

              {/* Embedded Search Keyword Matrix */}
              <div>
                <h4 className="text-xs font-semibold text-neutral-300 mb-2">
                  Indexed Search Queries (Bangla, English & Banglish):
                </h4>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  {SEO_SEARCH_KEYWORDS.join('  ·  ')}
                </p>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-4">
              <div className="rounded-xl border border-neutral-800 bg-neutral-950 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-emerald-400" />
                    <span className="text-sm font-semibold text-white">
                      Cryptographic Target Link Lock Active
                    </span>
                  </div>
                  <span className="font-mono-tabular text-xs text-emerald-400">
                    Checksum {securityStatus.checksumHex}
                  </span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Your destination link (<span className="text-white font-mono-tabular">{OFFICIAL_CONFIG.targetUrl}</span>) is frozen via{' '}
                  <code className="text-neutral-200">Object.freeze()</code> and continuously monitored by a real-time DOM{' '}
                  <code className="text-neutral-200">MutationObserver</code>. Even if a malicious browser extension or injected script tries to alter any link on the page, the guardian immediately restores your official admin tournament URL.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-neutral-800 text-xs">
                  <div>
                    <span className="text-neutral-500 block">Locked Destination</span>
                    <span className="font-mono-tabular text-white">busy-gamer-turnament.web.app</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">Protocol Enforcement</span>
                    <span className="font-mono-tabular text-emerald-400">Strict HTTPS + HSTS</span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block">Tamper Attempts Blocked</span>
                    <span className="font-mono-tabular text-white">{securityStatus.tamperAttemptsBlocked}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-xs text-neutral-300">
                <h4 className="font-semibold text-white">4 Layers of Anti-Hacker Defense Included:</h4>
                <p className="text-neutral-400">
                  01. <strong className="text-neutral-200">Zero Backend Attack Surface:</strong> Pure static architecture with no exposed database credentials or mutable server endpoints on the ad page.
                </p>
                <p className="text-neutral-400">
                  02. <strong className="text-neutral-200">DOM Link Mutation Guardian:</strong> Automatically reverts any unauthorized DOM modification of <code className="text-neutral-300">href</code> attributes every millisecond.
                </p>
                <p className="text-neutral-400">
                  03. <strong className="text-neutral-200">Content Security Policy (CSP) & Clickjacking Guard:</strong> Blocks unauthorized external scripts, iframe overlays, and MIME-sniffing attacks.
                </p>
                <p className="text-neutral-400">
                  04. <strong className="text-neutral-200">FNV-1a Checksum Verification:</strong> Verifies hostname integrity before executing any touch or button redirect.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'hosting' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold text-white">
                    Hardened <code className="text-amber-400">firebase.json</code> Configuration
                  </h4>
                  <p className="text-xs text-neutral-400">
                    Already saved in the project root alongside <code className="text-neutral-200">/public/robots.txt</code> and <code className="text-neutral-200">/public/sitemap.xml</code>.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(FIREBASE_JSON_SNIPPET, 'firebase')}
                  className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-800 px-3 py-1.5 text-xs font-medium text-white hover:bg-neutral-700 transition-colors whitespace-nowrap"
                >
                  {copiedId === 'firebase' ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy firebase.json</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 text-xs font-mono-tabular text-neutral-300 overflow-x-auto">
                {FIREBASE_JSON_SNIPPET}
              </pre>

              <div className="rounded-lg border border-neutral-800 bg-neutral-900/50 p-4 text-xs text-neutral-300 space-y-1.5">
                <div className="font-semibold text-white">Quick Deploy Steps (Firebase / Vercel / Netlify / Cloudflare Pages):</div>
                <p>1. Run <code className="text-amber-400">npm run build</code> to generate the production static bundle in <code className="text-neutral-200">dist/</code>.</p>
                <p>2. Run <code className="text-amber-400">firebase deploy --only hosting</code> to publish with all anti-hacker HTTP headers and SEO sitemaps active.</p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-neutral-800 bg-neutral-950 px-6 py-3.5">
          <span className="text-xs text-neutral-400">
            Destination: <strong className="text-neutral-200 font-mono-tabular">{OFFICIAL_CONFIG.targetUrl}</strong>
          </span>
          <div className="flex items-center gap-3">
            <a
              href={OFFICIAL_CONFIG.targetUrl}
              target="_blank"
              rel="noopener noreferrer"
              data-protected-link="true"
              className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-4 py-2 text-xs font-semibold text-neutral-950 hover:bg-amber-400 transition-colors whitespace-nowrap"
            >
              <span>Open Official App</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
