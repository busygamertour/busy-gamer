import heroArenaImg from '../assets/images/hero_esports_arena_1790437567126.jpg';
import battleRoyaleImg from '../assets/images/division_battle_royale_1790437585606.jpg';
import clashSquadImg from '../assets/images/division_clash_squad_1790437599005.jpg';

export const TOURNAMENT_IMAGES = {
  heroArena: heroArenaImg,
  battleRoyale: battleRoyaleImg,
  clashSquad: clashSquadImg,
};

export interface TournamentDivision {
  id: string;
  index: string;
  titleEn: string;
  titleBn: string;
  format: string;
  mapPool: string;
  entryFeeBdt: number;
  perKillBdt: number;
  totalPrizeBdt: number;
  dailySlots: string;
  descriptionEn: string;
  descriptionBn: string;
  image?: string;
  featured?: boolean;
}

export const TOURNAMENT_DIVISIONS: TournamentDivision[] = [
  {
    id: 'battle-royale-championship',
    index: '01',
    titleEn: 'Battle Royale Full-Map Championship',
    titleBn: 'ব্যাটল রয়্যাল ফুল-ম্যাপ চ্যাম্পিয়নশিপ (Free Fire & PUBG)',
    format: 'Solo · Duo · 4-Player Squad',
    mapPool: 'Bermuda · Purgatory · Erangel',
    entryFeeBdt: 20,
    perKillBdt: 15,
    totalPrizeBdt: 1200,
    dailySlots: '48 Players / Room · Every 60 Mins',
    descriptionEn:
      'Compete in referee-monitored full-map custom rooms. Earn instant payouts for every verified elimination plus guaranteed top-3 placement rewards.',
    descriptionBn:
      'প্রতিদিন রেফারি দ্বারা পরিচালিত কাস্টম রুমে অংশ নিন। প্রতিটি কিলের জন্য নিশ্চিত পুরস্কার এবং টপ-৩ বিজয়ীদের জন্য ইনস্ট্যান্ট বিকাশ/নগদ পেমেন্ট।',
    image: battleRoyaleImg,
    featured: true,
  },
  {
    id: 'clash-squad-tactical',
    index: '02',
    titleEn: '4v4 Clash Squad Tactical Showdown',
    titleBn: '৪ বনাম ৪ ক্ল্যাশ স্কোয়াড কাস্টম টুর্নামেন্ট',
    format: '4v4 Head-to-Head · Unlimited Ammo Room',
    mapPool: 'Custom Competitive Ruleset',
    entryFeeBdt: 80,
    perKillBdt: 0,
    totalPrizeBdt: 150,
    dailySlots: '2 Squads / Room · Instant Matchmaking',
    descriptionEn:
      'High-tempo 7-round custom rooms with character skill balance, no grenade spam rules, and direct winner-takes-all squad settlement.',
    descriptionBn:
      'আনলিমিটেড অ্যামো এবং ফেয়ার-প্লে রুলস সহ ৭ রাউন্ডের ৪ বনাম ৪ ক্ল্যাশ স্কোয়াড ম্যাচ। জিতলেই পুরো প্রাইজমানি সরাসরি আপনার ওয়ালেটে।',
    image: clashSquadImg,
    featured: true,
  },
  {
    id: 'lone-wolf-duel',
    index: '03',
    titleEn: '1v1 & 2v2 Lone Wolf Headshot Arena',
    titleBn: '১ বনাম ১ লোন উলফ ও হেডশট চ্যালেঞ্জ',
    format: '1v1 Duel · 2v2 Partner Clash',
    mapPool: 'Iron Cage · Training Grounds',
    entryFeeBdt: 30,
    perKillBdt: 0,
    totalPrizeBdt: 55,
    dailySlots: 'On-Demand Rooms · 12:00 PM – 11:30 PM',
    descriptionEn:
      'Pure mechanical skill duels with Desert Eagle, UMP, and M1887 weapon presets. Zero third-party interference and 10-minute payout turnaround.',
    descriptionBn:
      'নিজের গেমিং স্কিল প্রমাণ করার সেরা মঞ্চ। ১ বনাম ১ এবং ২ বনাম ২ কাস্টম ম্যাচে জয়ী হয়ে মাত্র ১০ মিনিটে পুরস্কারের টাকা উত্তোলন করুন।',
  },
  {
    id: 'free-entry-scrims',
    index: '04',
    titleEn: 'Daily Zero-Entry Sponsored Scrims',
    titleBn: 'প্রতিদিনের ফ্রি এন্ট্রি স্পন্সরড টুর্নামেন্ট',
    format: 'Solo & Squad · Free Registration',
    mapPool: 'Bermuda Remastered',
    entryFeeBdt: 0,
    perKillBdt: 5,
    totalPrizeBdt: 500,
    dailySlots: 'Daily at 8:00 PM & 10:00 PM BD Time',
    descriptionEn:
      'New to Busy Gamer Tournament? Enter our daily sponsored custom rooms at zero entry cost and win real wallet balance transferable to bKash or Nagad.',
    descriptionBn:
      'কোনো এন্ট্রি ফি ছাড়াই প্রতিদিন রাত ৮টা ও ১০টায় স্পন্সরড কাস্টম রুমে জয়েন করুন এবং জিতে নিন সরাসরি বিকাশ বা নগদ ক্যাশ রিওয়ার্ড।',
  },
];

export interface LiveScheduleSlot {
  matchCode: string;
  timeBd: string;
  division: string;
  mode: string;
  entryFee: string;
  prizePool: string;
  spotsFilled: string;
  statusLabel: string;
}

export const DAILY_SCHEDULE_SLOTS: LiveScheduleSlot[] = [
  {
    matchCode: 'BGT-401',
    timeBd: '04:00 PM',
    division: 'Battle Royale Solo',
    mode: 'Bermuda · Mobile Only',
    entryFee: '৳20',
    prizePool: '৳950',
    spotsFilled: '44 / 48',
    statusLabel: 'Room ID Ready in 10m',
  },
  {
    matchCode: 'BGT-402',
    timeBd: '05:30 PM',
    division: '4v4 Clash Squad',
    mode: 'Unlimited Ammo · No Grenade',
    entryFee: '৳80 / Squad',
    prizePool: '৳150',
    spotsFilled: '1 / 2 Squads',
    statusLabel: '1 Squad Slot Open',
  },
  {
    matchCode: 'BGT-403',
    timeBd: '08:00 PM',
    division: 'Sponsored Free Scrim',
    mode: 'Bermuda · Solo Survival',
    entryFee: '৳0 (Free)',
    prizePool: '৳500',
    spotsFilled: '41 / 48',
    statusLabel: 'Registration Open',
  },
  {
    matchCode: 'BGT-404',
    timeBd: '09:30 PM',
    division: 'Squad Championship',
    mode: 'Purgatory · 12 Squads',
    entryFee: '৳80 / Squad',
    prizePool: '৳1,200',
    spotsFilled: '10 / 12 Squads',
    statusLabel: 'Prime Time Featured',
  },
  {
    matchCode: 'BGT-405',
    timeBd: '10:30 PM',
    division: '1v1 Lone Wolf Duel',
    mode: 'Headshot Preset · Best of 9',
    entryFee: '৳30',
    prizePool: '৳55',
    spotsFilled: 'Open Queue',
    statusLabel: 'Instant Room Creation',
  },
];

export interface FaqItem {
  questionBn: string;
  questionEn: string;
  answerBn: string;
  answerEn: string;
}

export const TOURNAMENT_FAQS: FaqItem[] = [
  {
    questionBn: 'কিভাবে Busy Gamer Tournament অ্যাপে বা ওয়েবসাইটে জয়েন করব?',
    questionEn: 'How do I join a match on Busy Gamer Tournament?',
    answerBn:
      'এই পেজের যেকোনো জায়গায় টাচ বা ক্লিক করলেই আপনাকে সরাসরি আমাদের অফিসিয়াল ওয়েবসাইট (https://busy-gamer-turnament.web.app/) এ নিয়ে যাবে। সেখানে আপনার গেমের ইন-গেম নাম ও UID দিয়ে পছন্দমতো ম্যাচে রেজিস্ট্রেশন করতে পারবেন।',
    answerEn:
      'Tap anywhere on this promotional page or click the primary launch button to open our official tournament portal (https://busy-gamer-turnament.web.app/). Choose a match slot, enter your in-game UID, and receive Room ID & Password 10 minutes before match start.',
  },
  {
    questionBn: 'ম্যাচ জেতার কতক্ষণের মধ্যে প্রাইজমানি বিকাশ বা নগদে পাওয়া যায়?',
    questionEn: 'How quickly are prize payouts sent to bKash, Nagad, or Rocket?',
    answerBn:
      'ম্যাচ শেষ হওয়ার পর আমাদের রেফারি স্ক্রিনশট এবং কিল লগ যাচাই করে ১০ থেকে ১৫ মিনিটের মধ্যে আপনার প্রোফাইল ওয়ালেটে টাকা যোগ করে দেন। ওয়ালেট থেকে যেকোনো সময় ১ ক্লিকে বিকাশ, নগদ বা রকেটে উইথড্র করতে পারবেন।',
    answerEn:
      'Once the match ends, our room referee verifies the final scoreboard within 10–15 minutes and credits your winnings automatically. You can withdraw your balance anytime to bKash, Nagad, or Rocket.',
  },
  {
    questionBn: 'হ্যাকার বা পিসি এমুলেটর প্লেয়ারদের বিরুদ্ধে কী ব্যবস্থা নেওয়া হয়?',
    questionEn: 'How do you enforce anti-cheat and prevent hackers or PC emulators?',
    answerBn:
      'আমাদের প্রতিটি কাস্টম রুমে লাইভ স্পেক্টেটর অ্যাডমিন থাকে। পিসি এমুলেটর, হ্যাক, প্যানেল বা টিমিং প্রমাণিত হলে সাথে সাথে রুম থেকে কিক এবং অ্যাকাউন্ট স্থায়ীভাবে ব্যান করা হয়। শুধুমাত্র প্রকৃত মোবাইল গেমাররাই আমাদের টুর্নামেন্টে খেলতে পারে।',
    answerEn:
      'Every room is monitored live by an official spectator referee. PC emulators, third-party panels, auto-headshot scripts, and cross-squad teaming result in immediate removal from the room and permanent UID blacklisting.',
  },
  {
    questionBn: 'রুম আইডি এবং পাসওয়ার্ড কোথায় এবং কখন দেওয়া হয়?',
    questionEn: 'When and where are Custom Room ID and Password shared?',
    answerBn:
      'ম্যাচ শুরু হওয়ার ঠিক ১০ থেকে ১৫ মিনিট আগে আমাদের অফিসিয়াল অ্যাপ/ওয়েবসাইটের ভেতর আপনার জয়েন করা ম্যাচ কার্ডেই রুম আইডি ও পাসওয়ার্ড দেখানো হয়।',
    answerEn:
      'Custom Room ID and Password are published directly inside your registered match card on https://busy-gamer-turnament.web.app/ exactly 10 to 15 minutes before the scheduled start time.',
  },
];

export const SEO_SEARCH_KEYWORDS = [
  'Busy Gamer Tournament Official',
  'busy-gamer-turnament.web.app',
  'Free Fire Tournament Bangladesh bKash',
  'PUBG Mobile Custom Room BD',
  'বিজি গেমার টুর্নামেন্ট অ্যাপ',
  'ফ্রি ফায়ার টুর্নামেন্ট খেলে টাকা ইনকাম',
  'Daily Clash Squad 4v4 Custom Match',
  'Mobile Esports Tournament Bangladesh 2026',
  'Free Entry Gaming Tournament BD',
  '1v1 Lone Wolf Tournament App',
];
